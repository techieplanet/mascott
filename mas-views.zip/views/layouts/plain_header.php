<?php
    use yii\helpers\Html;
?>

<header class="main-header">
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" role="navigation">      
      <div class="navbar-custom-menu">
        <!--<ul class="nav navbar-nav"></ul>-->
      </div>
    </nav>
  </header>